"use strict";

/**
 * User sessions
 * @param {array} users
 */
var users = [],
	games = [],
	usersInGames = [];

/**
 * Find opponent for a user
 * @param {User} user
 */
function findOpponent(user) {


	for (var i = 0; i < users.length; i++) {
		if (user !== users[i]) {
			new Match(user, users[i]);
		}
	}
}

/**
 * Remove user session
 * @param {User} user
 */
function removeUser(user) {
	// if(users.indexOf(users) !== -1)
	return users.splice(users.indexOf(user), 1);
}

/**
 * Match class
 * @param {User} user1
 * @param {User} user2
 */
function Match(user1, user2) {

	// this.user1 = user1;
	// this.user2 = user2;
	var players = [user1,user2],
		playerIDs = [];
	for(var i=0,iL=players.length; i<iL; i++)
		playerIDs.push(players[i].socket.id.substr(2))
	this.game = new Game({
		server: true,
		players: players
	});
	games.push(this.game);
	user1.match = this;
	user2.match = this;
	usersInGames.push(removeUser(user1));
	usersInGames.push(removeUser(user2));

	for(var i=0,iL=players.length; i<iL; i++)
		players[i].socket.emit("start",{players:playerIDs});

}

function User(socket) {
	this.socket = socket;
	this.match = null;

	// this.opponent = null;
	// this.guess = GUESS_NO;
}

//  GET RID OF ANY DEAD GAMES EVERY TEN SECONDS
setInterval(function() {
	var deadGames = [];
	for(var i=0,iL=games.length; i<iL; i++) {
		if(Object.keys(games[i].players).length === 0)
			deadGames.push(games[i])
	}
	if(deadGames.length) {
		for(var i=0,iL=deadGames.length; i<iL; i++) {
			console.log("splicing game")
			games.splice(i,1);
		}
	}
	console.log(games.length);
},1000);

module.exports = function (socket) {
	var user = new User(socket);
	users.push(user);
	// console.log(users.length);
	findOpponent(user);

	 
	socket.on("disconnect", function () {
		console.log("Disconnected: " + socket.id);
		//  IF THE DISCONNECTED USER WAS IN A MATCH
		//  TELL THE SERVER GAME THAT THIS PLAYER HAS DISCONNECTED
		if(user.match !== null)
			user.match.game.disconnect(socket.id.substr(2));
		removeUser(user);

	});

	console.log("Connected: " + socket.id);
};